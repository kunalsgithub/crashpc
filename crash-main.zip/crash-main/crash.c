//SCRIPT WRITTEN HERE

#include<stdio.h>
#include<stdlib.h>

struct node{
	long int data[50];
	struct node* next;
};

int main(){
	while(1==1){
		struct node* head = (struct node*)malloc(sizeof(struct node));
	}
}



//SCRIPT WRITTEN HERE