# crash
Simple executable made in C to crash your PC.
